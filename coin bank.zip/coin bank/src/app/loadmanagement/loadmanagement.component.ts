import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-loadmanagement',
  templateUrl: './loadmanagement.component.html',
  styleUrls: ['./loadmanagement.component.css']
})
export class LoadmanagementComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
