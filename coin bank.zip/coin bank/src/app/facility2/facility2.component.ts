import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-facility2',
  templateUrl: './facility2.component.html',
  styleUrls: ['./facility2.component.css']
})
export class Facility2Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
