import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-payables',
  templateUrl: './payables.component.html',
  styleUrls: ['./payables.component.css']
})
export class PayablesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
