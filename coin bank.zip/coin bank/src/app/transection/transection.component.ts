import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-transection',
  templateUrl: './transection.component.html',
  styleUrls: ['./transection.component.css']
})
export class TransectionComponent implements OnInit {
  facilityFlag = ''
  constructor() { }

  ngOnInit() {
  }

}
